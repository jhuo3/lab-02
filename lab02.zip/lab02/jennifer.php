<?php 
$currentPage = "Jennifer A Ngene | Intro";
include "inc/jennifer-html-top.inc";
?>

<?php include "inc/jennifer-nav.inc"; ?>

		<main>
			<p>I was born in The Gambia in 1999 and was mostly raised between that country and Nigeria for the first few years of my life. In 2005, my family immigrated to the United States and settled in Minnesota with my uncle for the time being before moving to another city in the state to be closer to my father’s workplace. My parents came to the US to provide a better future and education for my little brother and I. And I have been grateful for the opportunities that I have been able to come upon because of this decision from my parents.</p>

			<p>View my original webpage <a href="http://csc174.org/assignment01/jngene/lab01/" target="_blank">here</a>.</p>
		</main>

<?php include "inc/main-nav.inc"; ?>

<?php include "inc/footer.inc"; ?>