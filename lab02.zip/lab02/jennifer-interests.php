<?php 
$currentPage = "Jennifer A Ngene | Interests";
include "inc/jennifer-html-top.inc";
?>

<?php include "inc/jennifer-nav.inc"; ?>

		<main>
			<h1>Interests</h1>

			<p>I had an immense passion for technology and being digitally creative for a really long time. I became interested in website design from one day stumbling upon the HTML and CSS of the blog themes for most of my favorite Tumblr users that I used to follow. This was around when I was in 10th grade. At the time, I didn’t know that the code that I was looking at was HTML, CSS, and some JavaScript. They all looked like letters and numbers to me and didn’t have any particular meaning. I did mess around with the CSS of the blog sites unknowingly. Usually inputting various color codes and font choices and refreshing the page to see the changes happen immediately. Along with that kind of experience, I also created and designed a website for the IB students at my high school using WIX as the website builder. So, I still was not explicitly working with the code of the website just quite yet.</p>
		</main>

<?php include "inc/main-nav.inc"; ?>

<?php include "inc/footer.inc"; ?>