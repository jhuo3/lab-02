<?php 
$currentPage = "Junting Chen| Activities";
include "inc/junting-html-top.inc";
?>

<?php include "inc/junting-nav.inc"; ?>

		<main>
			<h1>Activities</h1>

			<p>During the college time, I participate in the local Chinese Ensemble, we had lots of performances during each year, especially during the Chinese traditional festival. We have both ensemble and solo performance. I am also taking dancing and painting activities in my school to enrich my life. I persistent on my hobbies since high school time, and always being open-minded with any other new chances.</p>
		</main>

<?php include "inc/main-nav.inc"; ?>

<?php include "inc/footer.inc"; ?>