<?php 
$currentPage = "Junting Chen | Intro";
include "inc/junting-html-top.inc";
?>

<?php include "inc/junting-nav.inc"; ?>

		<main>
			<p>This is Junting Chen, a sophomore in University of Rochester, and I prefer Christy as my English name. I am major in Business and consider minoring in or BA computer science. Therefore, I took CSC 170 last semester for the foundation of CSC 174 this semester. Exploring opportunities during college life is my first goal, including life decisions, career path, and networking.</p>

			<p>View my original webpage <a href="http://csc174.org/assignment01/jchen126/lab01/home.php" target="_blank">here</a>.</p>
		</main>

<?php include "inc/main-nav.inc"; ?>

<?php include "inc/footer.inc"; ?>