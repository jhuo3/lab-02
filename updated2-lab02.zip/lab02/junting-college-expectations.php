<?php 
$currentPage = "Junting Chen| College Expectations";
include "inc/junting-html-top.inc";
?>

<?php include "inc/junting-nav.inc"; ?>

		<main>
			<h1>College Expectations</h1>

			<p>I am from China, but I have been to many places in the US, such as, LA, Francisco, Seattle, Chicago, New York and so forth. I am growing up while taking the global view which given me a broad mind. I like Rochester because of the snow and the lovely environment. I prefer relative quiet study spaces and relaxing study spaces. Rochester give me the best choice. My first year of college went very well as make a lot of friends from all over the world. We held many events during weekends and festivals.</p>
		</main>

<?php include "inc/main-nav.inc"; ?>

<?php include "inc/footer.inc"; ?>