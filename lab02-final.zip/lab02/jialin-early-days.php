<?php
$currentPage = "Jialin Huo| Early Days";
include "inc/jialin-html-top.inc";
?>

<?php include "inc/jialin-nav.inc"; ?>

	<main>
		<h1>Early Days</h1>

		<p>My hometown is in Shanghai, China, but I have moved to San Francisco Bay Area since when I was thirteen years old. I studied at a Christian school in which I skipped my eighth grade and started from high school immediately. During my fantastic four years in high school, I have demonstrated strong interest in visual designs and various categories of art including calligraphy, painting, photography, and etc. With further curiosity, I have begun learning the technological instruments and software, particularly Adobe Photoshop and Blender.</p>
	</main>

<?php include "inc/main-nav.inc"; ?>

<?php include "inc/footer.inc"; ?>