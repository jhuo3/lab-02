<?php 
$currentPage = "Jennifer A Ngene | Now";
include "inc/jennifer-html-top.inc";
?>

<?php include "inc/jennifer-nav.inc"; ?>

		<main>
			<h1>Now</h1>
			
			<p>It wasn’t until I got into university and took CSC 170 during my first year that I realized the importance of the code that I was messing with when changing the numbers and letters from the Tumblr blog themes. I was very interested in the class and was thoroughly excited to learn as much as I could while taking the course. I could also see the career path that I could follow if I were to gain more knowledge in the area of creating websites. But I soon realized that I wanted to do more. I realized the potential that the digital could have for my creativity. And that pretty much explains why I am now a Digital Media Studies major. It’s where I can get to show my skills and learn more about all things digital and to keep on doing my own kind of digital composition of turning the ideas that I have in my head into digital pieces.</p>
		</main>

<?php include "inc/main-nav.inc"; ?>		

<?php include "inc/footer.inc"; ?>